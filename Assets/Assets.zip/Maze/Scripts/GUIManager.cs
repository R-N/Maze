﻿using System;
using System.Collections.Generic;
using Maze.Inputs.GUI;
using UnityEngine;
using UnityEngine.UI;

namespace Maze {
    public  class GUIManager : MonoBehaviour{
        public static  GUIManager instance;

        public ButtonInput sprayButton;
        public Joystick sprayAim;
        public ButtonInput jumpButton;
        public ToggleInput runToggle;
        public Joystick moveJoystick;
        public SwipePanel lookPanel;

        public CancelArea cancelArea;

        public Image hpBarFill;
        public Text sprayCharge;
        public Image sprayRecharge;

        public static bool invertLookAxis = false;


        private void Start() {
            GUIManager.instance = this;
        }
        public static bool UseCancelArea(ICancelable user) {
            return instance.cancelArea.Use(user);
        }
        public static bool? ReleaseCancelArea(ICancelable user, Vector2 point) {
            return instance.cancelArea.Release(user, point);
        }

        public static bool? IsInCancelArea(ICancelable user, Vector2 point) {
            return instance.cancelArea.IsPointInArea(user, point);
        }

        public static void SetHPFill(float percent) {
            instance.hpBarFill.fillAmount = percent;
        }

        public static void SetSprayCharge(int charge) {
            instance.sprayCharge.text = charge.ToString();
        }

        static float lastSprayRecharge = 1;
        public static void SetSprayRecharge(float percent) {
            if (lastSprayRecharge == percent) {
                return;
            }
            instance.sprayRecharge.fillAmount = percent;
        }
    }
}
