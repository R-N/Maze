﻿using Maze.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Maze.Mechanics.Obstacle {
    public class Obstacle : MyBehaviour, IDbEntity, IGameObject{
        public int obstacleId;
        public bool groupsShareProblems = false;

        public int preferredProblemCount {
            get {
                int c = groupsShareProblems ? obstacleItemGroups.Length : 0;
                for (int i = 0; i < obstacleItemGroups.Length; ++i) {
                    if (groupsShareProblems) {
                        c = Mathf.Max(c, obstacleItemGroups[i].preferredProblemCount);
                    } else {
                        c += obstacleItemGroups[i].preferredProblemCount;
                    }
                }
                return c;
            }
        }
        [SerializeField]
        private int _position;
        public int position {
            get {
                return _position;
            }
            set {
                SetPosition(position);
            }
        }
        


        public void SetPosition(int position) {
            _position = position;
            Util.ParentAndCenter(transform, LevelManager.GetObstaclePosition(position));
        }

        public ObstacleItemGroup[] obstacleItemGroups;

        protected virtual void Start() {
            for (int i = 0; i < obstacleItemGroups.Length; ++i) {
                obstacleItemGroups[i].parent = this;
                obstacleItemGroups[i].groupId = i;
            }
        }

        public void LoadProblems(Problem[] probs) {
            Pool<Problem> pool = new Pool<Problem>(probs);
            for (int i = 0; i < obstacleItemGroups.Length; ++i) {
                obstacleItemGroups[i].LoadProblems(pool.Get(obstacleItemGroups[i].preferredProblemCount));
            }
        }

        public void Read(Database.Cursor cur, Reader reader) {
            position = reader.GetInt32("POS");
            cur.commandText = string.Format("SELECT * FROM OBSTACLE_ITEMS WHERE LEVEL_ID={0} AND OBSTACLE_LEVEL_ID={1} ORDER BY OBSTACLE_ITEM_GROUP_OBSTACLE, OBSTACLE_ID_GROUP", LevelManager.levelId, obstacleId);
            using(Reader reader2 = cur.ExecuteReader()){
                for(int i = 0; i < obstacleItemGroups.Length; ++i){
                    reader.Read();
                    obstacleItemGroups[i].Read(cur, reader2);
                }
            }
        }

        public void Save() {
            using (Database.Cursor cur = Database.Database.GetCursor()) {
                Save(cur);
            }
        }

        public void Save(Database.Cursor cur) {
            cur.commandText = String.Format("INSERT INTO OBSTACLE (LEVEL_ID, OBSTACLE_ID_LEVEL, NAME, POS) VALUES({0}, {1}, \"{2}\", {3});", LevelManager.levelId, obstacleId, gameObject.name.Replace("(Clone)", ""), position);
            
            int ret = cur.ExecuteNonQuery();

            for (int i = 0; i < obstacleItemGroups.Length; ++i) {
                obstacleItemGroups[i].Save(cur);
            }
        }
    }
}
