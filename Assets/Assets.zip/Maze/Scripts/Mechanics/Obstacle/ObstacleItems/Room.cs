﻿using Maze.Inputs;
using UnityEngine;
namespace Maze.Mechanics.Obstacle.ObstacleItems {
    public class Room : ObstacleItem {
        public Chest chest;
        public Door door;
        public bool isKeyRoom = false;

        public Transform obstaclePosition = null;

        public override int state {
            get {
                return chest.state;
            }
            set {
                chest.state = value;
            }
        }

        protected override void _LoadStatement(Statement statement) {
            chest.LoadStatement(statement);
        }

        public override void Save(Database.Cursor cur){
            if(chest) chest.Save(cur);
        }

        public override void Read(Database.Cursor cur, Database.Reader reader){
            if(chest != null){
                chest.Read(cur, reader);
            }
        }
    }
}
