﻿using Maze.Database;
using Maze.Inputs;
using UnityEngine;
using System.Text;
namespace Maze.Mechanics.Obstacle.ObstacleItems {
    public class Door : ObstacleItem {
        public Dialog dialog;
        public int keyId = 0;
        public Transform door;

        public Room target;

        public int from;
        public int to;

        public Portal portal;
        public Transform playerSpawnPosition;

        public KeyCheckerState _state = KeyCheckerState.unlocked;

        public bool isKeyDoor {
            get {
                return target.isKeyRoom;
            }
        }

        public override int state {
            get {
                return (int)_state;
            }
            set {
                _state = (KeyCheckerState)value;
            }
        }

        public void Start() {
        }

        protected override void _LoadStatement(Statement statement) {
            dialog.SetTitle("Door");
            dialog.SetText(statement.text);
            if(target != null) target.LoadStatement(statement);
        }

        public void Open() {
            door.gameObject.SetActive(false); //TODO
            _state = KeyCheckerState.opened;
        }

        public void SetTarget(Room room) {
            target = room;
            this.SetTarget(room.door);
            room.door.SetTarget(this);
        }

        public void SetTarget(Door door) {
            portal.target = door.playerSpawnPosition;
        }

        public void OnTryOpen(ButtonEventData data) {
            if (keyId == 0 || _state == KeyCheckerState.unlocked || data.actor.status.CheckStack(Control.BuffId.key, keyId) == keyId) {
                Open();
            }
        }
        
        public void SetPortal(int from, int to){
            this.from = from;
            this.to = to;

            Transform doorPos = LevelManager.GetPortalPosition(from);
            Room room = LevelManager.GetRoom(to);

            if(doorPos.childCount > 0) playerSpawnPosition = doorPos.GetChild(0);
            Util.ParentAndCenter(transform, doorPos);

            SetTarget(room);
            transform.localPosition += new Vector3(0, 0, 0.05f);

        }

        public override void Save(Database.Cursor cur){
            cur.commandText = string.Format("INSERT OR REPLACE INTO PORTAL VALUES({0}, {1}, {2}, {3}, {4}, {5})",
            LevelManager.levelId, from, to, statement.id, state, target ? 0 : target.state);
            cur.ExecuteNonQuery();
            if(target) target.Save(cur);
        }

        public override void Read(Database.Cursor cur, Database.Reader reader){
            state = reader.GetInt32("STATE");
            Statement statement = Problem.GetStatement(reader.GetInt32("ANSWER_ID"));
            LoadStatement(statement);
            if(target != null) target.Read(cur, reader);
        }
    }
}
