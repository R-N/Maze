﻿using Maze.Database;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Maze.Mechanics.Obstacle {
    public abstract class ObstacleItem : MyBehaviour, IGameObject, IReadOnlyDbEntity {
        public ObstacleItemGroup parent;
        public Statement statement;

        public int obstacleItemId;

        public void LoadStatement(Statement statement) {
            this.statement = statement;
            _LoadStatement(statement);
        }

        protected abstract void _LoadStatement(Statement statement);

        public abstract int state { get; set; }

        public void Save() {

            using (Database.Cursor cur = Database.Database.GetCursor()) {
                Save(cur);
            }
        }

        public virtual void Read(Database.Cursor cur, Reader reader){
            Statement s = Problem.GetStatement(reader.GetInt32("ANSWER_ID"));
            LoadStatement(s);
            state = reader.GetInt32("STATE");
        }
        public virtual void Save(Database.Cursor cur) {
            cur.commandText = String.Format("INSERT  INTO OBSTACLE_ITEM (LEVEL_ID, OBSTACLE_ID_LEVEL, OBSTACLE_ITEM_GROUP_OBSTACLE, OBSTACLE_ITEM_ID_GROUP, ANSWER_ID, STATE) VALUES({0}, {1}, {2}, {3}, {4}, {5});",
                LevelManager.levelId,
                parent.parent.obstacleId,
                parent.groupId,
                obstacleItemId,
                statement.id,
                state
                );
            int ret = cur.ExecuteNonQuery();
        }
    }
}
