﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System;
using Maze.Database;

namespace Maze.Mechanics.Obstacle {
    public class ObstacleItemGroup : MyBehaviour {
        public Obstacle parent;
        public ObstacleItem[] obstacleItems;
        public int groupId;
        public int correctAnswerCount = 1;
        public int preferredProblemCount = 1;

        private void Start() {
            for (int i = 0; i < obstacleItems.Length; ++i) {
                obstacleItems[i].parent = this;
                obstacleItems[i].obstacleItemId = i;
            }
        }

        public void LoadProblems(Problem[] problems) {
            problems = Util.RandomFilter(problems, preferredProblemCount);
            List<Statement> correctStatements = new List<Statement>();
            List<Statement> wrongStatements = new List<Statement>();
            for (int i = 0; i < problems.Length; ++i) {
                Util.AddToList(correctStatements, problems[i].GetStatements(true, correctAnswerCount));
                Util.AddToList(wrongStatements, problems[i].GetStatements(false, 5));
            }

            Pool<Statement> correctPool = new Pool<Statement>(correctStatements);
            Pool<Statement> wrongPool = new Pool<Statement>(wrongStatements);
            int maxCorrect = Mathf.Min(correctPool.Length + correctAnswerCount);

            List<Statement> statements = new List<Statement>();

            for (int i = 0; i < maxCorrect; ++i) {
                statements.Add(correctPool.Get());
            }
            for (int i = maxCorrect; i < obstacleItems.Length; ++i) {
                statements.Add(wrongPool.Get());
            }

            Pool<Statement> pool = new Pool<Statement>(statements);
            
            for (int i = 0; i < obstacleItems.Length; ++i) {
                obstacleItems[i].LoadStatement(pool.Get());
            }
        }
        public void RetrieveItems() {
            using (Database.Cursor cur = Database.Database.GetCursor()) {
                RetrieveItems(cur);
            }
        }

        public void RetrieveItems(Database.Cursor cur) {
            cur.commandText = String.Format("SELECT * FROM OBSTACLE_ITEM WHERE LEVEL_ID={0} AND OBSTACLE_ID_LEVEL={1} AND OBSTACLE_ITEM_GROUP_OBSTACLE={2} ORDER BY OBSTACLE_ITEM_ID_GROUP", LevelManager.levelId, parent.obstacleId, groupId);
            using (Reader reader = cur.ExecuteReader()) {
                Read(cur, reader);
            }
        }

        public void Read(Database.Cursor cur, Reader reader){
            for(int i = 0; i < obstacleItems.Length; ++i){
                reader.Read();
                obstacleItems[i].Read(cur, reader);
            }
        }

        public void Save() {

            using (Database.Cursor cur = Database.Database.GetCursor()) {
                Save(cur);
            }
        }
        public void Save(Database.Cursor cur) {
            for (int i = 0; i < obstacleItems.Length; ++i) {
                obstacleItems[i].Save(cur);
            }
        }
    }
}
