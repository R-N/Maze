﻿using Maze.Inputs;
using Maze.Inputs.GUI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Maze.Mechanics {
    public class Dialog : MonoBehaviour, IButton{
        public Text title;
        public Text text;
        public ButtonAction button;

        // Use this for initialization
        void Start() {
            
        }

        void Refresh() {
        }

        public void SetTitle(string title) {
            StartCoroutine("_SetTitle", title);
        }

        IEnumerator _SetTitle(string title) {
            yield return new WaitForEndOfFrame();
            this.title.text = title;
            this.title.GetComponent<ContentSizeFitter>().SetLayoutVertical();
            Refresh();
            yield return null;
        }

        public void SetText(string text) {
            StartCoroutine("_SetText", text);
        }

        IEnumerator _SetText(string text) {
            yield return new WaitForEndOfFrame();
            this.text.text = text;
            this.text.GetComponent<ContentSizeFitter>().SetLayoutVertical();
            Refresh();
            yield return null;
        }

        public void SetButtonEventHandler(ButtonEvent handler) {
            button.onClick = handler;
            Refresh();
        }

        public void SetButtonActive(bool active) {
            StartCoroutine("_SetButtonActive", active);
        }

        IEnumerator _SetButtonActive(bool active) {
            yield return new WaitForEndOfFrame();
            button.gameObject.SetActive(active);
            Refresh();
            yield return null;
        }
    }
}