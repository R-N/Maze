﻿using System.Collections.Generic;
using UnityEngine;
using Maze.Mechanics.Obstacle;
using Maze.Database;
using Maze.Mechanics;
using Maze.Mechanics.Obstacle.ObstacleItems;
using Maze.Control.Controllers;
using Maze.Level;
using UnityEngine.SceneManagement;

namespace Maze{
    public class LevelManager : MonoBehaviour{
        public class PortalData {
            public int from;
            public int to;
            public int answerId;
            public Door door;
            public Room room;
        }

        public static LevelData currentLevel = null;
        public static bool replay = false;

        public static int problemDifficulty = 0;
        public static Category[] problemCategories =null;

        public Transform[] _obstaclePositions;
        Pool<Transform> obstaclePositions;

        public Transform[] _playerRespawnPositions;
        Pool<Transform> playerRespawnPositions;

        public Transform[] _portalPositions;
        Pool<Transform> portalPositions;
        public Room[] _rooms;
        Pool<Room> rooms;
        public Obstacle[] _obstaclePool;
        Pool<Obstacle> obstaclePool;
        
        public PlayerController player;
        public Transform entryDoor;
        public Transform exitDoor;

        public Spray spray;

        public Door door;


        public Dictionary<string, Obstacle> obstacleByName = new Dictionary<string, Obstacle>();

        int entryPos;
        int exitPos;

        List<PortalData> doors = new List<PortalData>();


        public static LevelType type{
            get{
                return currentLevel.type;
            }
        }

        Dictionary<int, Obstacle> obstacles = new Dictionary<int, Obstacle>();

        public static int levelId {
            get {
                return currentLevel.id;
            }
        }

        static LevelManager instance;

        public List<Spray> sprays = new List<Spray>();


        private void Start() {
            instance = this;

            obstaclePositions = new Pool<Transform>(_obstaclePositions);
            playerRespawnPositions = new Pool<Transform>(_playerRespawnPositions);
            portalPositions = new Pool<Transform>(_portalPositions);
            rooms = new Pool<Room>(_rooms);
            obstaclePool = new Pool<Obstacle>(_obstaclePool);

            for (int i = 0; i < _obstaclePool.Length; ++i) {
                Obstacle obs = _obstaclePool[i];
                obstacleByName[obs.name] = obs;
            }
            //Random.seed = (int)(((long)(Time.realtimeSinceStartup * 1000))%int.MaxValue);
            Random.InitState((int)(((long)(Time.realtimeSinceStartup * 1000))%int.MaxValue));
            Generate();
        }
        
        public static void LoadLevel(LevelData data){
            currentLevel = data;
            SceneManager.LoadScene("Maze/Scenes/" + data.scene);
        }

        public static Transform GetRandomPlayerRespawn() {
            return instance.playerRespawnPositions.Get();
        }

        public static Transform GetObstaclePosition(int id) {
            return instance.obstaclePositions[id];
        }

        public void Generate() {


            entryPos = portalPositions.GetIndex();
            exitPos = portalPositions.GetIndex();

            SpawnEntryExit(entryPos, exitPos);
            SpawnPlayer();


            int obsCount = Mathf.Min(obstaclePool.Length, obstaclePositions.Length);
            int problemCount = 0;
            for (int i = 0; i < obsCount; ++i) {

                Obstacle obs = GameObject.Instantiate<Obstacle>(obstaclePool.Get());

                Util.ParentAndCenter(obs.transform, obstaclePositions.Get());

                obs.obstacleId = i;
                instance.obstacles[obs.obstacleId] = obs;

                problemCount += obs.preferredProblemCount;
            }


            int ppc = portalPositions.Length - 2; //-2 for entry and exit

            int portalCount = rooms.Length;
            problemCount += portalCount;
            
            for (int i = 0; i < portalCount; ++i) {
                int doorPosIndex = portalPositions.GetIndex();
                int roomIndex = rooms.GetIndex();


                MakePortal( doorPosIndex, roomIndex);
            }

            Problem[] problems = Problem.GetRandom(problemCount, problemDifficulty, problemCategories);

            Debug.Log("Problem count: " + problems.Length);

            Pool<Problem> problemPool = new Pool<Problem>(problems);

            foreach (Obstacle obs in instance.obstacles.Values) {
                Problem[] probs = problemPool.Get(obs.preferredProblemCount);
                obs.LoadProblems(probs);
            }

            Pool<PortalData> portalPool = new Pool<PortalData>(doors);
            for(int i = 0; i < portalCount; ++i){
                PortalData portal = portalPool.Get();
                Statement stat = problemPool.Get().GetStatements(portal.room.isKeyRoom || i% 2 == 0, 1)[0];
                portal.answerId = stat.id;
                portal.door.LoadStatement(stat);
            }
        }
        
        public void SpawnPlayer(){
            SpawnPlayer(entryPos);
        }
        public void SpawnPlayer(Database.Cursor cur){
            SpawnPlayer(cur, entryPos);
        }
        public void SpawnPlayer(int entryPos){
            using (Database.Cursor cur = Database.Database.GetCursor()){
                SpawnPlayer(cur, entryPos);
            }
        }

        public void SpawnPlayer(Database.Cursor cur, int entryPos){
            PlayerController player = GameObject.Instantiate<PlayerController>(this.player);
            Util.CopyTransform(player.transform, portalPositions[entryPos].GetChild(0));

            //Get previous level HP
        }

        public void SpawnEntryExit(int entryPos, int exitPos){
            this.entryPos = entryPos;
            this.exitPos = exitPos;

            Transform entry = portalPositions[entryPos];
            Transform entryDoor = GameObject.Instantiate<Transform>(this.entryDoor);
            Util.ParentAndCenter(entryDoor, entry);
            entryDoor.transform.localPosition += new Vector3(0, 0, 0.05f);

            Transform exit = portalPositions[exitPos];
            Transform exitDoor = GameObject.Instantiate<Transform>(this.exitDoor);
            Util.ParentAndCenter(exitDoor, exit);
            exitDoor.transform.localPosition += new Vector3(0, 0, 0.05f);
        }
        public PortalData MakePortal(int doorPosId, int roomId) {

            Door door = GameObject.Instantiate<Door>(this.door);
            door.SetPortal(doorPosId, roomId);

            PortalData data = new PortalData();
            data.from = doorPosId;
            data.to = roomId;
            data.door = door;
            data.room = door.target;

            doors.Add(data);

            return data;
        }

        public static Transform GetPortalPosition(int index){
            return instance.portalPositions[index];
        }
        public static Room GetRoom(int index){
            return instance.rooms[index];
        }

        public static void OnLevelClear() {
            Debug.Log("LEVEL CLEAR");
            instance.Save();
        }

        public static void RegisterSpray(Spray spray){
            Debug.Log("REGISTER SPRAY");
            instance.sprays.Add(spray);
        }

        public void Save() {
            using (Database.Cursor cur = Database.Database.GetCursor()){

                cur.commandText = string.Format("INSERT OR REPLACE INTO LEVEL_COMPLETION VALUES({0}, {1}, {2}, {3})",
                levelId, PlayerController.instance.status.hpCur, entryPos, exitPos);
                cur.ExecuteNonQuery();

                //if(type == LevelType.preLevel){
                    //overwrite

                //cur.commandText = string.Format("DELETE FROM OBSTACLE_ITEM WHERE OBSTACLE_ITEM.OBSTACLE_ID_LEVEL IN (SELECT OBSTACLE.OBSTACLE_ID_LEVEL FROM OBSTACLE WHERE OBSTACLE.LEVEL_ID={0})", levelId);
                cur.commandText = string.Format("DELETE FROM OBSTACLE_ITEM WHERE LEVEL_ID={0}", levelId);
                cur.ExecuteNonQuery();
                cur.commandText = string.Format("DELETE FROM OBSTACLE WHERE LEVEL_ID={0}", levelId);
                cur.ExecuteNonQuery();
                
                cur.commandText = string.Format("DELETE FROM PORTAL WHERE LEVEL_ID={0}", levelId);
                cur.ExecuteNonQuery();

                cur.commandText = string.Format("DELETE FROM TRANSFORM WHERE TRANSFORM.TRANSFORM_ID IN (SELECT SPRAY.TRANSFORM_ID FROM SPRAY WHERE SPRAY.LEVEL_ID={0})", levelId);
                cur.ExecuteNonQuery();


                cur.commandText = string.Format("DELETE FROM SPRAY WHERE LEVEL_ID={0}", levelId);
                cur.ExecuteNonQuery();


                //save
                foreach(Obstacle o in obstacles.Values){
                    o.Save(cur);
                }
                foreach(PortalData portal in doors){
                    portal.door.Save(cur);
                }
                Debug.Log("Saving Sprays: " + sprays.Count);
                foreach(Spray s in sprays){
                    s.Save(cur);
                }
                //}
            }
        }

        public void Load(int levelId, bool reverseEntryExit = true, bool spawnSprays=true) {
            using (Database.Cursor cur = Database.Database.GetCursor()){
                cur.commandText = string.Format("SELECT * FROM LEVEL_COMPLETION WHERE LEVEL_ID={0}", levelId);
                
                using(Reader reader = cur.ExecuteReader()){
                    reader.Read();
                    entryPos = reader.GetInt32("ENTRY_POS");
                    exitPos = reader.GetInt32("EXIT_POS");
                }
                
                if(reverseEntryExit){
                    SpawnEntryExit(exitPos, entryPos);
                }else{
                    SpawnEntryExit(entryPos, exitPos);
                }
                SpawnPlayer(cur);

                cur.commandText = string.Format("SELECT * FROM PORTAL WHERE LEVEL_ID={0}", levelId);
                using(Reader reader = cur.ExecuteReader()){
                    while(reader.Read()){
                        int from = reader.GetInt32("FROM_POS");
                        int to = reader.GetInt32("TO_POS");
                        PortalData data = MakePortal(from, to);
                        data.door.Read(cur, reader);
                        /* 
                        data.door.LoadStatement(Problem.GetStatement(reader.GetInt32("ANSWER_ID")));
                        data.door.state = reader.GetInt32("STATE");
                        data.room.state = reader.GetInt32("CHEST_STATE");
                        */
                    }
                }

                cur.commandText = string.Format("SELECT * FROM OBSTACLE WHERE LEVEL_ID={0} ORDER BY OBSTACLE_ID_LEVEL", levelId);
                using (Reader reader = cur.ExecuteReader()){
                    while(reader.Read()){
                        string name = reader.GetString("NAME");
                        int pos = reader.GetInt32("POS");

                        Obstacle obs = GameObject.Instantiate<Obstacle>(obstacleByName[name]);

                        Util.ParentAndCenter(obs.transform, obstaclePositions[pos]);

                        obs.obstacleId = reader.GetInt32("OBSTACLE_ID_LEVEL");
                        instance.obstacles[obs.obstacleId] = obs;

                        obs.Read(cur, reader);
                    }
                }

                if(spawnSprays){
                    cur.commandText = string.Format("SELECT * FROM SPRAY, TRANSFOR WHERE SPRAY.LEVEL_ID={0} AND SPRAY.TRANSFORM_ID=TRANSFORM.TRANSFORM_ID", levelId);
                    using (Reader reader = cur.ExecuteReader()){
                        Spray spray =GameObject.Instantiate<Spray>(this.spray);

                        spray.Read(cur, reader);

                        //spray.transform.position = new Vector3(reader.GetFloat("POS_X"), reader.GetFloat("POS_Y"), reader.GetFloat("POS_Z"));
                        //spray.transform.rotation = new Quaternion(reader.GetFloat("ROT_X"), reader.GetFloat("ROT_Y"), reader.GetFloat("ROT_Z"), reader.GetFloat("ROT_W"));
                    }
                }
            }
        }
    }
}
