﻿using System.Data;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Maze.Database {
    public interface IDbEntity : IReadOnlyDbEntity {
        void Save();
        void Save(Cursor cursor);
    }
}
