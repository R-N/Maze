﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Maze {
    public class MyBehaviour : MonoBehaviour {
        public virtual void OnControllerColliderHit(ControllerColliderHit hit) {

        }
    }
}
