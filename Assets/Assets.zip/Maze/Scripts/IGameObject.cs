﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Maze {
    public interface IGameObject {
        GameObject gameObject {
            get;
        }
    }
}
