﻿using Maze.Database;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using UnityEngine;
using UnityEngine.UI;

namespace Maze.Level {
    public class LevelPackData : IReadOnlyDbEntity{

        public int id;
        public string name;
        public Sprite background;
        public Sprite thumbnail;
        public LevelData[] preLevels;
        public LevelData treasure;
        public LevelData[] postLevels;
        
        public bool unlocked = false;

        public LevelPackData(){}

        public LevelPackData(Database.Cursor cur, Reader reader){
            Read(cur, reader);
        }

        public void Read(Database.Cursor cur, Reader reader) {
            id = (int)reader.GetInt32("LEVEL_PACK_ID");
            name = reader.GetString("NAME");
            unlocked = reader.GetBool("UNLOCKED");

            LevelPack.dataCache[id] = this;
            //TODO: background
            //TODO: thumbnail

            RetrieveItems(cur);
        }

        public void RetrieveItems(){

            using(Database.Cursor cur = Database.Database.GetCursor()){
                RetrieveItems(cur);
            }
        }
        public void RetrieveItems(Database.Cursor cur){
            List<LevelData> preLevels = new List<LevelData>();
            cur.commandText = string.Format("SELECT * FROM LEVEL WHERE LEVEL_PACK_ID={0} AND TYPE={1}", id, (int)LevelType.preLevel);
            using(Reader reader = cur.ExecuteReader()){
                while(reader.Read()){
                    LevelData data = Level.ReadStatic(cur, reader);
                    data.SetParent(this);
                    preLevels.Add(data);
                }
            }
            this.preLevels = preLevels.ToArray();

            cur.commandText = string.Format("SELECT * FROM LEVEL WHERE LEVEL_PACK_ID={0} AND TYPE={1} LIMIT 1", id, (int)LevelType.bossLevel);
            using(Reader reader = cur.ExecuteReader()){
                while(reader.Read()){
                    treasure = Level.ReadStatic(cur, reader);
                    treasure.SetParent(this);
                }
            }
            
            List<LevelData> postLevels = new List<LevelData>();
            cur.commandText = string.Format("SELECT * FROM LEVEL WHERE LEVEL_PACK_ID={0} AND TYPE={1}", id, (int)LevelType.postLevel);
            using(Reader reader = cur.ExecuteReader()){
                while(reader.Read()){
                    LevelData data = Level.ReadStatic(cur, reader);
                    data.SetParent(this);
                    postLevels.Add(data);
                }
            }
            this.postLevels = postLevels.ToArray();
        }
        public void CheckUnlock(){
            using(Database.Cursor cur = Database.Database.GetCursor()){
                CheckUnlock(cur);
            }
        }
        public void CheckUnlock(Database.Cursor cur){
            throw new System.NotImplementedException();
            //TODO
        }
    }
    public class LevelPack : MonoBehaviour, IReadOnlyDbEntity{

        public static Dictionary<int, LevelPackData> dataCache = new Dictionary<int, LevelPackData>();
        public Text text;
        public Image image;
        LevelPackData data;

        public LevelPackMenu menu;

        public void SetData(LevelPackData data){
            this.data =data;
        }

        public void Init(){
            text.text = data.name;
            //TODO: levelImage
        }
        public void OnClick(){
            menu.LoadLevelPack(data);
        }

        public void Read(Database.Cursor cur, Reader reader)
        {
            int id = (int)reader.GetInt32("LEVEL_PACK_ID");
            LevelPackData data;
            if(dataCache.ContainsKey(id)){
                data = dataCache[id];
            }else{
                data = new LevelPackData();
            }
            data.Read(cur, reader);
            SetData(data);

            RetrieveItems(cur);
        }
        public void RetrieveItems(){

            using(Database.Cursor cur = Database.Database.GetCursor()){
                RetrieveItems(cur);
            }
        }
        public void RetrieveItems(Database.Cursor cur){
            data.RetrieveItems(cur);
        }

        public void CheckUnlock(){
            using(Database.Cursor cur = Database.Database.GetCursor()){
                CheckUnlock(cur);
            }
        }
        public void CheckUnlock(Database.Cursor cur){
            data.CheckUnlock(cur);
        }
        public static LevelPackData GetLevelPackData(int id){
            if(dataCache.ContainsKey(id)){
                return dataCache[id];
            }else{
                throw new System.NotImplementedException();
                //TODO
            }
        }
        public void SetParent(Transform parent, bool worldPostionStays = false){
            transform.SetParent(parent, worldPostionStays);
        }
    }
}
